$('.carousel').carousel({
        interval: 5000 //changes the speed
    })

$('[data-spy="scroll"]').each(function () {
  var $spy = $(this).scrollspy('refresh')
})

// Smooth scroll
$(function() {
  $('#navbar-html-example a[href*=#]:not([href=#])').click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html,body').animate({
          scrollTop: target.offset().top
        }, 1000);
        return false;
      }
    }
  });
});

// Home work
$(document).ready(function() {
 
  $("#home-work").owlCarousel({
 
      autoPlay: 6000, //Set AutoPlay to 3 seconds
 
      items : 4,
      itemsDesktop : [1199,3],
      itemsDesktopSmall : [979,3]
 
  });
 
});


// Footer testimonials
$(document).ready(function() {
 
  $("#footer-testimonials").owlCarousel({
 
      navigation : false, // Show next and prev buttons
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem:true
 
      // "singleItem:true" is a shortcut for:
      // items : 1, 
      // itemsDesktop : false,
      // itemsDesktopSmall : false,
      // itemsTablet: false,
      // itemsMobile : false
 
  });
 
});

// Remove Placeholder
$('input,textarea').focus(function(){
   $(this).data('placeholder',$(this).attr('placeholder'))
   $(this).attr('placeholder','');
});
$('input,textarea').blur(function(){
   $(this).attr('placeholder',$(this).data('placeholder'));
});


    //Tab to top
    $(window).scroll(function() {
    if ($(this).scrollTop() > 1){  
        $('.scroll-top-wrapper').addClass("show");
    }
    else{
        $('.scroll-top-wrapper').removeClass("show");
    }
});
    $(".scroll-top-wrapper").on("click", function() {
     $("html, body").animate({ scrollTop: 0 }, 600);
    return false;
});


  //Sticky Header

$(window).scroll(function() {
    if ($(this).scrollTop() > 1){  
        $('.logo-menu').addClass("sticky-menu");
    }
    else{
        $('.logo-menu').removeClass("sticky-menu");
    }
});


//Favicon
(function() {
    var link = document.createElement('link');
    link.type = 'image/x-icon';
    link.rel = 'shortcut icon';
    link.href = 'img/icon.png';
    document.getElementsByTagName('head')[0].appendChild(link);
}());

//Pricing Circle
 $('#circle25').circleProgress({
        value: 0.25,
        size: 80,
        startAngle:100,
        thickness:15,
        fill: {
            gradient: ["red", "orange"]
        }
    });
 $('#circle50').circleProgress({
        value: 0.50,
        size: 80,
        startAngle:100,
        thickness:15,
        fill: {
            gradient: ["red", "orange"]
        }
    });
 $('#circle75').circleProgress({
        value: 0.75,
        size: 80,
        startAngle:100,
        thickness:15,
        fill: {
            gradient: ["red", "orange"]
        }
    });
 $('#circle90').circleProgress({
        value: 0.90,
        size: 80,
        startAngle:100,
        thickness:15,
        fill: {
            gradient: ["red", "orange"]
        }
    });
// Animations
new WOW().init();